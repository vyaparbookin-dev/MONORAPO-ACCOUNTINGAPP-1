import mongoose from "mongoose";

const productSchema = new mongoose.Schema({
  // Basic Info
  name: { type: String, required: true },
  description: String,
  site: String,
  companyId: { type: mongoose.Schema.Types.ObjectId, ref: "Company", required: true },
  
  // Category & Classification
  category: { type: String, required: true }, // Electronics, Textiles, etc.
  subCategory: String,
  hsnCode: { type: String, default: "" }, // HSN Code for GST (Made optional to fix Excel Imports)
  image: { type: String }, // Base64 compressed image
  
  // Codes & Identifiers
  sku: { type: String }, // Auto-generated
  barcode: { type: String, sparse: true }, // Optional & Unique if provided
  
  // Pricing
  dpl: { type: Number, default: 0 }, // Company Rate / Basic Rate
  costPrice: { type: Number, required: true }, // Cost to you
  sellingPrice: { type: Number, required: true }, // Sell price
  wholesalePrice: { type: Number, default: 0 }, // Wholesale Rate
  dealerPrice: { type: Number, default: 0 },
  p3Rate: { type: Number, default: 0 }, // Extra rate mapped in import
  discount: { type: Number, default: 0 }, // Primary Discount % (Jaise normal 5%)
  secondaryDiscount: { type: Number, default: 0 }, // Secondary/Scheme Discount % (Jaise 5+2% me 2%)
  cashDiscount: { type: Number, default: 0 }, // Cash Discount (CD) % (Jaise CD 1%)
  discountDisplayFormat: { type: String }, // Text format save karne ke liye jaise: "5+2% + CD 1%"
  mrp: Number, // Maximum Retail Price
  
  // Tax & GST
  gstRate: { type: Number, default: 0 }, // 0%, 5%, 12%, 18%, 28%
  gstType: { type: String, enum: ["CGST", "SGST", "IGST"], default: "CGST" },
  
  // Units & Quantity
  unit: { type: String, required: true }, // kg, ltr, pcs, ft, mtr, etc.
  secondaryUnit: { type: String }, // Box, Carton, Dozen etc.
  conversionRate: { type: Number, default: 1 }, // 1 Box = 10 pcs
  minimumStock: { type: Number, default: 10 },
  maximumStock: { type: Number, default: 0 },
  currentStock: { type: Number, default: 0 },
  stockLocations: [{
    branchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch' },
    warehouseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Warehouse' },
    quantity: { type: Number, default: 0 }
  }],
  
  // For Restaurants / Manufacturing (Recipe & Raw Materials)
  isRawMaterial: { type: Boolean, default: false }, // True if this is a raw material like 'Flour', 'Sugar', 'Fabric'
  recipe: [{ // Bill of Materials (BOM) - Ek dish banane me kya kya use hota hai
    rawMaterialId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    quantity: { type: Number, required: true }, // Kitni quantity lagegi
    unit: String
  }],
  productionCost: { type: Number, default: 0 }, // Per dish cost (raw materials se calculate hoke yahan aayegi)

  // For Jewellery Business
  weight: { type: Number }, // Weight in grams or mg
  purity: { type: String }, // e.g., '22K', '24K', '925 Silver'
  makingChargeType: { type: String, enum: ['per_gram', 'fixed', 'percentage'], default: 'fixed' },
  makingCharge: { type: Number, default: 0 },

  // For Hardware / Builders
  brand: String,
  dimensions: String, // e.g., '8x4 ft', '12mm'

  // For Science & Sports
  materialType: String, // e.g., 'Borosilicate Glass', 'Leather'
  ageGroup: String, // e.g., 'U-14', 'Adults' (for sports)
  certification: String, // e.g., 'ISO 9001', 'ISI'
  warrantyPeriod: String, // e.g., '6 Months', '1 Year'

  // Tracking
  supplier: String,
  reorderQuantity: Number,
  
  // Metadata
  isActive: { type: Boolean, default: true },
  synced: { type: Boolean, default: false },
  source: { type: String, default: 'manual' }, // Tracking kahan se add hua
  importBatchId: { type: String }, // Excel upload ko group (Batch 1, Batch 2) karne ke liye

  // Flexible fields for different business types
  customFields: { type: Map, of: String },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
}, { strict: true }); // ✅ Set to true for production to enforce schema and prevent unexpected fields.

// Compound indexes to ensure uniqueness per company
productSchema.index({ companyId: 1, name: 1 }, { unique: true });
productSchema.index({ companyId: 1, sku: 1 }, { unique: true });
productSchema.index({ companyId: 1, barcode: 1 }, { unique: true });

// Auto-generate SKU if not provided
productSchema.pre("save", async function (next) {
  if (!this.sku) {
    const count = await mongoose.model("Product").countDocuments({ companyId: this.companyId });
    this.sku = `SKU-${Date.now()}-${count}`;
  }
  
  if (!this.barcode) {
    this.barcode = `BAR-${this.sku}`;
  }
  
  this.updatedAt = Date.now();
  next();
});

export default mongoose.model("Product", productSchema);