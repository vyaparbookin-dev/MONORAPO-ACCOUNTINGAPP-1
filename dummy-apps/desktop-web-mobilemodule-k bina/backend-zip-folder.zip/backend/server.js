import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import connectDB from "./src/config/db.js";
import { errorHandler } from "./src/middleware/errormiddleware.js"; // Changed SRC to src
import path from "path";
import "./src/config/firebase.js"; // Initialize Firebase on start
import { fileURLToPath } from "url";
import fs from "fs";
import rateLimit from "express-rate-limit";
import * as Sentry from "@sentry/node";

// Route Imports
import authRoutes from "./src/routes/authRoutes.js";
import billingRoutes from "./src/routes/billingRoutes.js";
import licensingRoutes from "./src/routes/licensingRoutes.js";
import branchRoutes from "./src/routes/branchRoutes.js";
import companyRoutes from "./src/routes/companyRoutes.js";
import couponRoutes from "./src/routes/couponRoutes.js";
import expensesRoutes from "./src/routes/expensesRoutes.js";
import inventoryRoutes from "./src/routes/inventoryRoutes.js";
import laterpadRoutes from "./src/routes/laterpadRoutes.js";
import membershipRoutes from "./src/routes/membershipRoutes.js";
import notificationRoutes from "./src/routes/notificationRoutes.js";
import paymentRoutes from "./src/routes/paymentRoutes.js";
import partyRoutes from "./src/routes/partyRoutes.js";
import reportRoutes from "./src/routes/reportRoutes.js";
import salaryRoutes from "./src/routes/salaryRoutes.js";
import staffRoutes from "./src/routes/staffRoutes.js";
import schemeRoutes from "./src/routes/schemeRoutes.js";
import securityRoutes from "./src/routes/securityRoutes.js";
import warehouseRoutes from "./src/routes/warehouseRoutes.js";
import syncRoutes from "./src/routes/syncRoutes.js";
import consolidatedStatementRoutes from "./src/routes/consolidatedStatementRoutes.js";
import purchaseRoutes from "./src/routes/purchaseRoutes.js";
import purchaseOrderRoutes from "./src/routes/purchaseOrderRoutes.js";
import bankRecRoutes from "./src/routes/bankRecRoutes.js";
import tdsTcsRoutes from "./src/routes/tdsTcsRoutes.js";
import fixedAssetRoutes from "./src/routes/fixedAssetRoutes.js";
import eWayBillRoutes from "./src/routes/eWayBillRoutes.js";
import returnRoutes from "./src/routes/returnRoutes.js";
import daybookRoutes from "./src/routes/daybookRoutes.js";
import b2bRoutes from "./src/routes/b2bRoutes.js";
import gstRoutes from "./src/routes/gstRoutes.js";
import stockTransferRoutes from "./src/routes/stockTransferRoutes.js";
import userRoutes from "./src/routes/userRoutes.js";
import attendanceRoutes from "./src/routes/attendanceRoutes.js";
import categoryRoutes from "./src/routes/categoryRoutes.js";
import unitRoutes from "./src/routes/unitRoutes.js";
import cloudRoutes from "./src/routes/cloudRoutes.js";
import settingsRoutes from "./src/routes/settingsRoutes.js";
import agingRoutes from "./src/routes/agingRoutes.js";
import approvalRoutes from "./src/routes/approvalRoutes.js";
import whatsappRoutes from "./src/routes/whatsappRoutes.js";
import reminderRoutes from "./src/routes/reminderRoutes.js";
import brandRoutes from "./src/routes/brandRoutes.js";
import subCategoryRoutes from "./src/routes/subCategoryRoutes.js";
import { startCronJobs } from "./src/utils/cronJobs.js";
import tallyRoutes from "./src/routes/tallyRoutes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const envLocalPath = path.resolve(__dirname, ".env.local");
const envExamplePath = path.resolve(__dirname, ".env.example");
if (fs.existsSync(envLocalPath)) {
  dotenv.config({ path: envLocalPath });
  console.log("👉 Loaded keys from .env.local");
} else {
  dotenv.config({ path: envExamplePath });
  console.log("👉 Loaded keys from .env.example");
}
console.log("👉 CHECK LOADED URI:", process.env.MONGO_URI);

// --- DEBUGGING: Check if Brevo key is loaded correctly ---
console.log("🔑 Checking Brevo Key:", process.env.BREVO_API_KEY ? `Loaded (${process.env.BREVO_API_KEY.substring(0, 4)}...)` : "NOT FOUND!");

// Initialize Sentry for Error Tracking
Sentry.init({
  dsn: process.env.SENTRY_DSN, // Aap ise baad me .env me dalenge
  environment: process.env.NODE_ENV || "development",
});

// Log uncaught errors for debugging
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  Sentry.captureException(err, { level: 'fatal' });
  process.exit(1); // Force exit, so nodemon can restart cleanly
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  Sentry.captureException(reason, { level: 'fatal' });
  process.exit(1); // Force exit, so nodemon can restart cleanly
});
const app = express();

// Trust proxy for Render deployment (Required for express-rate-limit to work behind a proxy)
app.set('trust proxy', 1);


// --- Secure CORS Configuration ---
const allowedOrigins = [
  'http://localhost:5173', // Web Dev (Vite)
  'http://localhost:3000', // Web Dev (Create React App)
  'http://localhost:8082', // Mobile Dev
  'http://localhost:5174', // Desktop Dev
  'https://monorapo-accountingapp-1-web.vercel.app' // Vercel URL ko permanently add kar dein
];

// Dynamically add the production frontend URL from environment variables
if (process.env.FRONTEND_URL) {
  allowedOrigins.push(process.env.FRONTEND_URL);
}

const corsOptions = {
  origin: (origin, callback) => {
    // Allow requests with no origin, whitelisted origins, and ANY Vercel auto-generated URL.
    if (!origin || allowedOrigins.indexOf(origin) !== -1 || (origin && origin.endsWith('.vercel.app'))) {
      callback(null, true);
    } else {
      console.error(`CORS Blocked Origin: ${origin}`);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
};
app.use(cors(corsOptions));

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Apply API Rate Limiting (DDoS Protection)
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500, // Limit each IP to 500 requests per 15 minutes
  message: { success: false, message: "Too many requests from this IP, please try again after 15 minutes" },
  validate: { xForwardedForHeader: false } // FIX: Stops the 'trust proxy' error on Render
});

// Apply rate limiter specifically to all API routes
app.use("/api", apiLimiter);

app.get("/", (req, res) => res.send("Vyapar Backend Running ✅"));

// Render dynamically assigns a PORT, use 5001 as fallback for local dev
const PORT = process.env.PORT || 5001;

app.use("/api/auth", authRoutes);
app.use("/api/billing", billingRoutes);
app.use("/api/branch", branchRoutes);
app.use("/api/company", companyRoutes);
app.use("/api/aging", agingRoutes);
app.use("/api/approvals", approvalRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/b2b", b2bRoutes);
app.use("/api/bank-rec", bankRecRoutes);
app.use("/api/category", categoryRoutes);
app.use("/api/subcategory", subCategoryRoutes);
app.use("/api/brand", brandRoutes);
app.use("/api/cloud", cloudRoutes);
app.use("/api/consolidated-statement", consolidatedStatementRoutes);
app.use("/api/coupon", couponRoutes);
app.use("/api/daybook", daybookRoutes);
app.use("/api/ewaybill", eWayBillRoutes);
app.use("/api/expenses", expensesRoutes); // Consolidated to a single, standard route
app.use("/api/fixed-assets", fixedAssetRoutes);
app.use("/api/gst", gstRoutes);
app.use("/api/inventory", inventoryRoutes);
app.use("/api/laterpad", laterpadRoutes);
app.use("/api/licensing", licensingRoutes);
app.use("/api/membership", membershipRoutes);
app.use("/api/notification", notificationRoutes);
app.use("/api/party", partyRoutes);
app.use("/api/payment", paymentRoutes);
app.use("/api/purchase", purchaseRoutes);
app.use("/api/purchase-orders", purchaseOrderRoutes);
app.use("/api/reminders", reminderRoutes);
app.use("/api/report", reportRoutes);
app.use("/api/return", returnRoutes);
app.use("/api/salary", salaryRoutes);
app.use("/api/scheme", schemeRoutes);
app.use("/api/security", securityRoutes);
app.use("/api/settings", settingsRoutes);
app.use("/api/staff", staffRoutes);
app.use("/api/stock-transfer", stockTransferRoutes);
app.use("/api/sync", syncRoutes);
app.use("/api/tally", tallyRoutes);
app.use("/api/tds-tcs", tdsTcsRoutes);
app.use("/api/unit", unitRoutes);
app.use("/api/user", userRoutes);
app.use("/api/warehouse", warehouseRoutes);
app.use("/api/whatsapp", whatsappRoutes);
app.use("/api/reports", reportRoutes);
app.use("/api/schemes", schemeRoutes);
app.use("/api/logs", securityRoutes);
const stubRouter = express.Router();
stubRouter.all('*', (req, res) => res.json({ success: true, message: "Feature coming soon / API under construction" }));
app.use("/api/roles", stubRouter);
app.use("/api/leaves", stubRouter);
app.use("/api/keys", stubRouter);
Sentry.setupExpressErrorHandler(app);
app.use(errorHandler);
app.use((req, res) => {
  console.log(`⚠️ 404 Route Not Found: ${req.method} ${req.originalUrl}`);
  res.status(404).json({ message: `Route not found: ${req.originalUrl}` });
});

const startServer = () => {
  app.listen(PORT, '0.0.0.0', async () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📡 Backend accessible at http://localhost:${PORT}`);
    try {
      await connectDB();
      startCronJobs();
    } catch (error) {
      console.error("❌ DB Connection Failed:", error);
      Sentry.captureException(error);
    }
  });
};

startServer();
