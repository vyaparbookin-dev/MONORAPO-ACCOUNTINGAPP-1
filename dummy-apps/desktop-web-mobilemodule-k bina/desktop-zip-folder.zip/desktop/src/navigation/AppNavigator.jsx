import React from "react";
import { Routes, Route, Outlet } from "react-router-dom";
import DashboardLayout from "../components/DashboardLayout";
import { webFeatureRoutes } from "./WebRoutes"; // Import the route definitions
// Auth Screens
import LoginScreen from "../screens/Auth/LoginScreen";
import RegisterScreen from "../screens/Auth/RegisterScreen";
import ForgotPasswordScreen from "../screens/Auth/ForgotPasswordScreen";
import KeyreCoveryPage from "../screens/Auth/KeyreCoveryPage";
import VerifyOtp from "../pages/setting/VerifyOtp";

// Dashboard
import Dashboard from "../screens/Dashboard/DashboardScreen";
// ApprovalsPage is now in webFeatureRoutes

// Parties
// PartiesPage is now in webFeatureRoutes

// Billing
import BillingPage from "../screens/Billing/BillingPage";
import BillListPage from "../screens/Billing/BillListPage";
import BillDetailPage from "../screens/Billing/BillDetailPage";
import FastPOSPage from "../screens/Billing/FastPOSPage";
import ImportBillPage from "../screens/Billing/ImportBillPage";
import ParseBillFromImage from "../screens/Billing/ParseBillFromImage";
import SalesReturnPage from "../screens/Billing/SalesReturnPage";
import CreateReturnPage from "../screens/returns/CreateReturnPage";
// B2bDocumentListPage is now in webFeatureRoutes
// CreateB2bDocumentPage is now in webFeatureRoutes

// Inventory
import InventoryPage from "../screens/inventory/InventoryPage";
import AddProductPage from "../screens/inventory/AddProductPage";
import BulkProductPage from "../screens/inventory/BulkProductPage";
import BulkUploadPage from "../screens/inventory/BulkUploadPage";
import CategoryAnalyticsPage from "../screens/inventory/CategoryAnalyticsPage";
// PurchaseEntryPage is still here
import StockAdjustmentPage from "../screens/inventory/StockAdjustmentPage";
import ProductListPage from "../screens/inventory/ProductListPage";
import ProductDetailPage from "../screens/inventory/ProductDetailPage";
import SerialBatchPage from "../screens/inventory/SerialBatchPage";
import InventorySalesReturnPage from "../screens/inventory/SalesReturnPage";
import InventorySupplierLedgerPage from "../screens/inventory/SupplierLedgerPage";
import StockTransferPage from "../screens/inventory/StockTransferPage";
import ParsePurchaseBillPage from "../screens/inventory/ParseBillFromImage";
import CategoryManagementPage from "../screens/inventory/CategoryManagementPage";
import ItemMasterPage from "../screens/inventory/ItemMasterPage";

// Expenses
import ExpensesPage from "../screens/expenses/ExpensesPage.jsx";
import AddExpensePage from "../screens/expenses/AddExpensePage";
import ExpensesListPage from "../screens/expenses/ExpensesListPage";

// Company
import CompanyPage from "../screens/company/CompanyPage";
import AddCompanyPage from "../screens/company/AddCompanyPage";
import BranchPage from "../screens/company/BranchPage";
import CompanyListPage from "../screens/company/CompanyListPage";

// Coupons
import CouponsPage from "../screens/coupons/CouponsPage";
import CouponListPage from "../screens/coupons/CouponListPage";
import GenerateCouponPage from "../screens/coupons/GenerateCouponPage";

// Membership
import MembershipPage from "../screens/membership/MembershipPage";
import MembershipListPage from "../screens/membership/MemberShipListPage";
import LoyaltyDetailPage from "../screens/membership/LoyaltyDetailPage";

// Notifications
import NotificationPage from "../screens/notification/NotificationPage";
import ReminderPage from "../screens/notification/ReminderPage";

// Reports
import ReportsPage from "../screens/Reports/ReportsPage";
import GstReportPost from "../screens/Reports/GstReportPage";
import ProductGstReportPage from "../screens/Reports/ProductGstReportPage";
import Gstr3bReportPage from "../screens/Reports/Gstr3bReportPage";
import ItemWiseReport from "../screens/Reports/ItemWiseReport";
import ItemWiseReportPage from "../screens/Reports/ItemWiseReportpage";
import BillWiseReportPage from "../screens/Reports/BillWiseReportPage";
import CustomerReportBuilder from "../screens/Reports/CustomerReportBuilder";
import PartyWiseReportPage from "../screens/Reports/PartyWiseReportPage";
import ProfitLossReportPage from "../screens/Reports/ProfitLossReport";
import SchemeReportPage from "../screens/Reports/SchemeReportPage";
import SupplierLedgerPage from "../screens/Reports/SupplierLedgerPage";
import DayBookPage from "../screens/Reports/DayBookPage";
import SitewiseReportPage from "../screens/Reports/SitewiseReportPage";
import AgingReportPage from "../screens/Reports/AgingReportPage";
// GraphicalAnalytics is still here
// BankReconciliationPage is now in webFeatureRoutes
// EWayBillPage is now in webFeatureRoutes
// FixedAssetsPage is now in webFeatureRoutes
// TdsTcsPage is now in webFeatureRoutes

// Salary
// SalaryPage is still here
import AddSalaryPage from "../screens/salary/AddSalaryPage";
import MarkAttendancePage from "../screens/salary/MarkAttendancePage";
import StaffStatementPage from "../screens/salary/StaffStatementPage";
import SalaryListPage from "../screens/salary/SalaryListPage";

// Laterpad (Late Payments)
import LaterpadPage from "../screens/laterpad/LaterpadPage";
// LaterpadListPage is now in webFeatureRoutes

// Warehouse
// AddWarehousePage is still here
import WarehouseListPage from "../screens/warehouse/WareHouseListPage";

// Settings
import SettingsPage from "../screens/Settings/SettingsPage";
import AppSettings from "../screens/Settings/AppSettingPage";
import BackupRestore from "../screens/Settings/BackupRestore";
import ProfilePage from "../screens/Settings/ProfilePage";
import SecurityLogPage from "../screens/Settings/SecurityLogPage";
import WebPreferences from "../screens/Settings/WebPreferences";
import StaffManagementPage from "../screens/Settings/StaffManagementPage";

// Additional Settings Pages (from pages/setting)
import PageAppSettings from "../pages/setting/appsetting";
import PageCloudSync from "../pages/setting/cloudSync";
import PageProfile from "../pages/setting/profile";
import PageSecurityLog from "../pages/setting/securityLog";
import PageSettings from "../pages/setting/settings";
import UnitSettingsPage from "../screens/Settings/UnitSettingsPage";
import StaffPerformancePage from "../screens/Settings/StaffPerformancePage";

import WhatsappSettingsPage from "../screens/Settings/WhatsappSettingsPage";

const AppRoutes = () => {
  return (
    <Routes>
      {/* Auth Routes - No Layout */}
      <Route path="/login" element={<LoginScreen />} />
      <Route path="/register" element={<RegisterScreen />} />
      <Route path="/forgot-password" element={<ForgotPasswordScreen />} />
      <Route path="/key-recovery" element={<KeyreCoveryPage />} />
      <Route path="/verify-otp" element={<VerifyOtp />} />

      {/* Main App Routes - With Dashboard Layout (Protected) */}
      <Route element={<DashboardLayout><Outlet/></DashboardLayout>}>
        {/* Dashboard */}
        <Route path="/" element={<Dashboard />} />
        <Route path="/dashboard" element={<Dashboard />} />

        {/* Approvals */}
        <Route path="/approvals" element={<ApprovalsPage />} />
        {/* Parties */}
        <Route path="/parties" element={<PartiesPage />} />
        {/* Fast POS */}
        <Route path="/fast-pos" element={<FastPOSPage />} />

        {/* Billing */}
        <Route path="/billing" element={<BillingPage />} />
        <Route path="/billing/list" element={<BillListPage />} />
        <Route path="/billing/import" element={<ImportBillPage />} />
        <Route path="/billing/parse" element={<ParseBillFromImage />} />
        <Route path="/billing/return" element={<SalesReturnPage />} />
        <Route path="/billing/return/create" element={<CreateReturnPage />} />
        <Route path="/billing/b2b" element={<B2bDocumentListPage />} />
        <Route path="/billing/b2b/create" element={<CreateB2bDocumentPage />} />
        <Route path="/billing/:id" element={<BillDetailPage />} />

        {/* Inventory */}
        <Route path="/inventory" element={<InventoryPage />} />
        <Route path="/inventory/add" element={<AddProductPage />} />
        <Route path="/inventory/bulk" element={<BulkProductPage />} />
        <Route path="/inventory/bulk-upload" element={<BulkUploadPage />} />
        <Route path="/inventory/analytics" element={<CategoryAnalyticsPage />} />
        <Route path="/inventory/purchase" element={<PurchaseEntryPage />} />
        <Route path="/inventory/adjust" element={<StockAdjustmentPage />} />
        <Route path="/inventory/list" element={<ProductListPage />} />
        <Route path="/inventory/detail/:id" element={<ProductDetailPage />} />
        <Route path="/inventory/batch" element={<SerialBatchPage />} />
        <Route path="/inventory/purchase-return" element={<InventorySalesReturnPage />} />
        <Route path="/inventory/supplier-ledger" element={<InventorySupplierLedgerPage />} />
        <Route path="/inventory/transfer" element={<StockTransferPage />} />
        <Route path="/inventory/parse-purchase-bill" element={<ParsePurchaseBillPage />} />
        <Route path="/inventory/categories" element={<CategoryManagementPage />} />
        <Route path="/inventory/masters" element={<ItemMasterPage />} />

        {/* Expenses */}
        <Route path="/expenses" element={<ExpensesPage />} />
        <Route path="/expenses/add" element={<AddExpensePage />} />
        <Route path="/expenses/list" element={<ExpensesListPage />} />

        {/* Company */}
        <Route path="/company" element={<CompanyPage />} />
        <Route path="/company/add" element={<AddCompanyPage />} />
        <Route path="/company/branches" element={<BranchPage />} />
        <Route path="/company/list" element={<CompanyListPage />} />

        {/* Coupons */}
        <Route path="/coupans" element={<CouponsPage />} />
        <Route path="/coupons" element={<CouponsPage />} />
        <Route path="/coupons/list" element={<CouponListPage />} />
        {/* <Route path="/coupons/view" element={<CouponPage />} /> */}
        <Route path="/coupons/generate" element={<GenerateCouponPage />} />

        {/* Membership */}
        <Route path="/membership" element={<MembershipPage />} />
        <Route path="/membership/list" element={<MembershipListPage />} />
        <Route path="/membership/loyalty/:id" element={<LoyaltyDetailPage />} />

        {/* Notifications */}
        <Route path="/notifications" element={<NotificationPage />} />
        <Route path="/notifications/reminders" element={<ReminderPage />} />

        {/* Reports */}
        <Route path="/reports" element={<ReportsPage />} />
        <Route path="/reports/gst" element={<GstReportPost />} />
        <Route path="/reports/product-gst" element={<ProductGstReportPage />} />
        <Route path="/reports/gstr3b" element={<Gstr3bReportPage />} />
        <Route path="/reports/itemwise" element={<ItemWiseReport />} />
        <Route path="/reports/itemwise-page" element={<ItemWiseReportPage />} />
        <Route path="/reports/billwise" element={<BillWiseReportPage />} />
        <Route path="/reports/customer" element={<CustomerReportBuilder />} />
        <Route path="/reports/partywise" element={<PartyWiseReportPage />} />
        <Route path="/reports/profitloss" element={<ProfitLossReportPage />} />
        <Route path="/reports/scheme" element={<SchemeReportPage />} />
        <Route path="/reports/supplier-ledger" element={<SupplierLedgerPage />} />
        <Route path="/reports/daybook" element={<DayBookPage />} />
        <Route path="/reports/sitewise" element={<SitewiseReportPage />} />
        <Route path="/reports/analytics" element={<GraphicalAnalytics />} />

        {/* Salary */}
        <Route path="/salary" element={<SalaryPage />} />
        <Route path="/salary/add" element={<AddSalaryPage />} />
        <Route path="/salary/attendance" element={<MarkAttendancePage />} />
        <Route path="/salary/statement" element={<StaffStatementPage />} />
        <Route path="/salary/list" element={<SalaryListPage />} />

        {/* Cash & Bank */}
        {/* <Route path="/banking" element={<BankReconciliationPage />} /> */}

        {/* Late Payments */}
        <Route path="/laterpad" element={<LaterpadPage />} />

        {/* Warehouse */}
        <Route path="/warehouse/add" element={<AddWarehousePage />} />
        <Route path="/warehouse/list" element={<WarehouseListPage />} />
        <Route path="/warehouse" element={<WarehouseListPage />} />

        {/* Settings */}
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/settings/app" element={<AppSettings />} />
        <Route path="/settings/backup" element={<BackupRestore />} />
        <Route path="/settings/profile" element={<ProfilePage />} />
        <Route path="/settings/security" element={<SecurityLogPage />} />
        <Route path="/settings/web" element={<WebPreferences />} />
        <Route path="/settings/staff" element={<StaffManagementPage />} />
        <Route path="/settings/whatsapp" element={<WhatsappSettingsPage />} />
        <Route path="/settings/units" element={<UnitSettingsPage />} />
        <Route path="/settings/performance" element={<StaffPerformancePage />} />
        {webFeatureRoutes.map((route, index) => (
          <Route key={index} path={route.path} element={route.element} />
        ))}
      </Route>
    </Routes>
  );
};

export default AppRoutes;