const fs = require('fs');
const path = require('path');

// process.cwd() ka matlab hai jahan se aapne terminal command chalayi hai (Project Root)
const targetDir = process.cwd(); 

// Faltu folders ko ignore karenge taaki tree clean rahe
const ignoreList = [
  'node_modules', 
  '.git', 
  'build', 
  'dist', 
  '.expo', 
  '.next', 
  'android', 
  'ios', 
  'coverage',
  '.idea',
  '.vscode'
];

function generateTree(dir, prefix = '') {
  let tree = '';
  try {
    const files = fs.readdirSync(dir);
    const filteredFiles = files.filter(file => !ignoreList.includes(file));

    filteredFiles.forEach((file, index) => {
      const isLast = index === filteredFiles.length - 1;
      const filePath = path.join(dir, file);
      
      let isDirectory = false;
      try {
        isDirectory = fs.statSync(filePath).isDirectory();
      } catch (e) {}

      tree += prefix + (isLast ? '└── ' : '├── ') + file + '\n';

      if (isDirectory) {
        tree += generateTree(filePath, prefix + (isLast ? '    ' : '│   '));
      }
    });
  } catch (err) {
    // Ignore unreadable directories
  }
  return tree;
}

console.log(`🔍 Scanning directory: ${targetDir}`);
console.log("⏳ Generating tree...");

const projectTree = "Project Root: " + targetDir + "\n\n" + generateTree(targetDir);

const outputPath = path.join(targetDir, 'project-tree-full.txt');
fs.writeFileSync(outputPath, projectTree);

console.log(`✅ DONE! File created at: `);
