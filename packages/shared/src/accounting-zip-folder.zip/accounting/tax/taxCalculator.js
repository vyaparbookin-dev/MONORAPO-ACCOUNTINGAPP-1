// Common Tax Logic for Web, Mobile & Desktop
import { roundToDecimal } from '../money/rounding';

export const calculateGST = (amount, rate) => {
  const taxAmount = roundToDecimal((amount * rate) / 100);
  const totalAmount = roundToDecimal(amount + taxAmount);
  
  return { 
    tax: taxAmount,
    gst: taxAmount,
    total: totalAmount,
    taxAmount
  };
};

export const calculateTaxBreakdown = (amount, cgst, sgst, igst = 0) => {
  const cgstAmt = roundToDecimal((amount * cgst) / 100);
  const sgstAmt = roundToDecimal((amount * sgst) / 100);
  const igstAmt = roundToDecimal((amount * igst) / 100);
  const total = roundToDecimal(amount + cgstAmt + sgstAmt + igstAmt);
  return { cgstAmt, sgstAmt, igstAmt, total };
};

// Aliases for backward compatibility with Mobile App
export const calculateTax = calculateGST;

export const gstCalculator = (amount, rate) => {
  const result = calculateGST(amount, rate);
  return { gstAmount: result.tax, total: result.total };
};