// This file will define the core GST rules for the accounting engine.
// It should be pure and not depend on external state (like company settings).
// Inputs: placeOfSupply, sellerState, buyerState, itemGstRate, itemHsnCode, etc.
// Outputs: Applicable GST type (CGST/SGST or IGST), effective rate.

/**
 * Determines the applicable GST type (IGST or CGST+SGST) based on supply location.
 * @param {string} sellerState - State of the seller (e.g., "Maharashtra")
 * @param {string} buyerState - State of the buyer (e.g., "Maharashtra")
 * @param {string} placeOfSupply - Place of supply (usually buyer's state, but can differ)
 * @returns {'IGST' | 'CGST_SGST' | 'UNKNOWN'}
 */
export const determineGstType = (sellerState, buyerState, placeOfSupply) => {
  const normalizedSellerState = sellerState ? sellerState.toLowerCase().trim() : '';
  const normalizedBuyerState = buyerState ? buyerState.toLowerCase().trim() : '';
  const normalizedPlaceOfSupply = placeOfSupply ? placeOfSupply.toLowerCase().trim() : normalizedBuyerState; // Default to buyerState if placeOfSupply not provided

  if (!normalizedSellerState || !normalizedPlaceOfSupply) {
    // Cannot determine GST type without seller state and place of supply
    return 'UNKNOWN';
  }

  if (normalizedSellerState === normalizedPlaceOfSupply) {
    return 'CGST_SGST'; // Intra-state supply
  }
  return 'IGST'; // Inter-state supply
};

// Future functions could include:
// - getGstRateByHsn(hsnCode, date)
// - isExempt(item)
// - getCessRate(item)