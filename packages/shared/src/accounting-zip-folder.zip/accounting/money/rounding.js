// This file will contain utilities for safe monetary rounding.
// JavaScript floating-point arithmetic can be imprecise, so specific rounding strategies are needed.

const CALCULATION_PRECISION = 2; // Default to 2 decimal places for currency
/**
 * Rounds a number to a specified number of decimal places.
 * Uses a method to avoid floating point inaccuracies.
 * @param {number} value - The number to round.
 * @param {number} [decimals=2] - The number of decimal places.
 * @returns {number} The rounded number.
 */
export const roundToDecimal = (value, decimals = 2) => {
  if (typeof value !== 'number' || isNaN(value)) {
    return 0;
  }
  const factor = Math.pow(10, decimals);
  return Math.round(value * factor) / factor;
};

/**
 * Rounds a monetary value to the nearest integer (e.g., for final grand total).
 * @param {number} value - The monetary value.
 * @returns {number} The rounded integer.
 */
export const roundToNearestInteger = (value) => {
  if (typeof value !== 'number' || isNaN(value)) {
    return 0;
  }
  return Math.round(value);
};

// Future functions could include:
// - roundToNearestFivePaise(value)
// - floorToDecimal(value, decimals)
// - ceilToDecimal(value, decimals)