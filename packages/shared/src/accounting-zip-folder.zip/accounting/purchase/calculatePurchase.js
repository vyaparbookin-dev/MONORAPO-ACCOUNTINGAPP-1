// This file will contain the core logic for calculating all totals for a purchase invoice.
// It should be pure and deterministic.

import { calculateTaxBreakdown, calculateGST } from '../tax/taxCalculator';
import { determineGstType } from '../tax/gstRules';
import { roundToDecimal } from '../money/rounding';

const CALCULATION_VERSION = "1.0.0"; // Define a version for this calculation logic

/**
 * Calculates all financial totals for a purchase invoice.
 * @param {object} purchaseInput - Raw input for the purchase.
 * @param {string} purchaseInput.buyerState - State of the buying company.
 * @param {string} purchaseInput.sellerState - State of the supplier.
 * @param {string} [purchaseInput.placeOfSupply] - Place of supply (defaults to buyerState if not provided).
 * @param {Array<object>} purchaseInput.items - Array of item objects.
 * @param {number} purchaseInput.items[].quantity - Quantity of the item.
 * @param {number} purchaseInput.items[].rate - Rate per unit of the item.
 * @param {number} purchaseInput.items[].gstRate - GST rate for the item (e.g., 18 for 18%).
 * @param {boolean} [purchaseInput.items[].taxInclusive=false] - Is the item rate tax-inclusive?
 * @param {number} [purchaseInput.items[].itemDiscount=0] - Item-level discount amount.
 * @param {number} [purchaseInput.items[].cessRate=0] - Item-level cess rate (%).
 * @param {number} [purchaseInput.items[].cessAmount=0] - Item-level fixed cess amount.
 * @param {number} [purchaseInput.invoiceDiscount=0] - Overall invoice discount amount.
 * @param {'PRE_TAX' | 'POST_TAX'} [purchaseInput.invoiceDiscountType='POST_TAX'] - Type of invoice discount.
 * @param {number} [purchaseInput.freightCharges=0] - Freight charges.
 * @param {number} [purchaseInput.otherCharges=0] - Other charges.
 * @param {number} [purchaseInput.roundOff=0] - Round-off amount.
 * @returns {object} - Object containing all calculated totals and item-level breakdowns.
 */
export const calculatePurchase = (purchaseInput) => {
  let subtotal = 0;
  let totalTaxableAmount = 0;
  let totalCGST = 0;
  let totalSGST = 0;
  let totalIGST = 0;
  let totalCess = 0;
  let totalTotalTax = 0;
  let totalGrossAmount = 0;
  let totalItemDiscountAmount = 0;

  // --- Input Validation ---
  if (!purchaseInput || !purchaseInput.items || !Array.isArray(purchaseInput.items) || purchaseInput.items.length === 0) {
    throw new Error("Validation Error: Purchase must contain at least one item.");
  }
  if (!purchaseInput.buyerState) {
    throw new Error("Validation Error: Buyer state is required for tax calculation.");
  }
  if (!purchaseInput.sellerState) {
    throw new Error("Validation Error: Seller state is required for tax calculation.");
  }

  const invoiceDiscount = roundToDecimal(purchaseInput.invoiceDiscount || 0);
  const invoiceDiscountType = purchaseInput.invoiceDiscountType || 'POST_TAX'; // Default to POST_TAX
  const freightCharges = roundToDecimal(purchaseInput.freightCharges || 0);
  const otherCharges = roundToDecimal(purchaseInput.otherCharges || 0);
  const roundOff = roundToDecimal(purchaseInput.roundOff || 0);

  // Determine GST type for the entire purchase context
  const gstType = determineGstType(purchaseInput.sellerState, purchaseInput.buyerState, purchaseInput.placeOfSupply || purchaseInput.buyerState);

  // --- Phase 1: Calculate Item-level subtotals and pre-discount taxable amounts ---
  const preDiscountItems = purchaseInput.items.map(item => {
    const quantity = roundToDecimal(item.quantity || 0);
    const rate = roundToDecimal(item.rate || 0);
    const itemGstRate = roundToDecimal(item.gstRate || 0);
    const taxInclusive = item.taxInclusive || false;
    const itemDiscount = roundToDecimal(item.itemDiscount || 0); // Item-level discount
    const cessRate = roundToDecimal(item.cessRate || 0);
    const cessAmount = roundToDecimal(item.cessAmount || 0);

    if (quantity <= 0) throw new Error(`Validation Error: Item '${item.name || 'Unnamed'}' quantity must be positive.`);
    if (rate < 0) throw new Error(`Validation Error: Item '${item.name || 'Unnamed'}' rate cannot be negative.`);
    if (itemGstRate < 0) throw new Error(`Validation Error: Item '${item.name || 'Unnamed'}' GST rate cannot be negative.`);

    const grossAmount = roundToDecimal(quantity * rate); // Qty * Rate
    const effectiveItemDiscount = roundToDecimal(Math.min(itemDiscount, grossAmount)); // Clamp item discount
    const itemSubtotalAfterDiscount = roundToDecimal(grossAmount - effectiveItemDiscount); // This is the base for taxable amount

    return {
      ...item,
      quantity,
      rate,
      itemGstRate,
      taxInclusive,
      itemDiscountAmount: effectiveItemDiscount,
      grossAmount: grossAmount,
      itemSubtotalAfterDiscount: itemSubtotalAfterDiscount,
      cessRate,
      cessAmount,
      itemTaxableValueBeforeInvoiceDiscount: 0,
      itemTotalTaxBeforeInvoiceDiscount: 0,
      itemCGSTBeforeInvoiceDiscount: 0,
      itemSGSTBeforeInvoiceDiscount: 0,
      itemIGSTBeforeInvoiceDiscount: 0,
      itemCessBeforeInvoiceDiscount: 0,
    };
  });

  // --- Phase 2: Apply PRE_TAX invoice discount and calculate item taxes ---
  let totalTaxableValueBeforeInvoiceDiscount = roundToDecimal(preDiscountItems.reduce((sum, item) => {
    if (item.taxInclusive && item.itemGstRate > 0) {
      return sum + roundToDecimal(item.itemSubtotalAfterDiscount / (1 + item.itemGstRate / 100));
    }
    return sum + item.itemSubtotalAfterDiscount;
  }, 0));

  const finalProcessedItems = preDiscountItems.map(item => {
    let itemTaxableValue = item.itemSubtotalAfterDiscount;
    let itemTotalTax = 0;
    let itemCGST = 0;
    let itemSGST = 0;
    let itemIGST = 0;
    let itemCess = 0;

    // Apply PRE_TAX invoice discount proportionally
    if (invoiceDiscountType === 'PRE_TAX' && invoiceDiscount > 0) {
      if (totalTaxableValueBeforeInvoiceDiscount > 0) {
        const proportionalDiscount = roundToDecimal((itemTaxableValue / totalTaxableValueBeforeInvoiceDiscount) * invoiceDiscount);
        itemTaxableValue = roundToDecimal(itemTaxableValue - proportionalDiscount);
      }
    }

    // Ensure itemTaxableValue doesn't go negative after all discounts
    itemTaxableValue = Math.max(0, itemTaxableValue);

    if (item.itemGstRate > 0) {
      if (item.taxInclusive) {
        const inclusiveAmount = itemTaxableValue;
        itemTaxableValue = roundToDecimal(inclusiveAmount / (1 + item.itemGstRate / 100));
        itemTotalTax = roundToDecimal(inclusiveAmount - itemTaxableValue);
      } else {
        itemTotalTax = roundToDecimal(itemTaxableValue * (item.itemGstRate / 100));
      }

      if (gstType === 'CGST_SGST') {
        itemCGST = roundToDecimal(itemTotalTax / 2);
        itemSGST = roundToDecimal(itemTotalTax / 2);
      } else { // IGST
        itemIGST = roundToDecimal(itemTotalTax);
      }
    }

    // Calculate Cess
    if (item.cessRate > 0) {
      itemCess = roundToDecimal(itemTaxableValue * (item.cessRate / 100));
    } else if (item.cessAmount > 0) {
      itemCess = item.cessAmount;
    }

    const itemGrandTotal = roundToDecimal(itemTaxableValue + itemTotalTax + itemCess);

    // Accumulate totals
    totalGrossAmount = roundToDecimal(totalGrossAmount + item.grossAmount);
    totalItemDiscountAmount = roundToDecimal(totalItemDiscountAmount + item.itemDiscountAmount);
    totalTaxableAmount = roundToDecimal(totalTaxableAmount + itemTaxableValue);
    totalCGST = roundToDecimal(totalCGST + itemCGST);
    totalSGST = roundToDecimal(totalSGST + itemSGST);
    totalIGST = roundToDecimal(totalIGST + itemIGST);
    totalCess = roundToDecimal(totalCess + itemCess);
    totalTotalTax = roundToDecimal(totalTotalTax + itemTotalTax);

    return {
      ...item,
      itemTaxableValue: itemTaxableValue,
      itemCGST: itemCGST,
      itemSGST: itemSGST,
      itemIGST: itemIGST,
      itemCess: itemCess,
      itemTotalTax: itemTotalTax,
      itemGrandTotal: itemGrandTotal,
    };
  });

  // --- Phase 3: Calculate Purchase-level totals ---
  let finalGrandTotal = roundToDecimal(totalTaxableAmount + totalTotalTax + totalCess + freightCharges + otherCharges - (invoiceDiscountType === 'POST_TAX' ? invoiceDiscount : 0) + roundOff);

  // Ensure grandTotal doesn't go negative
  finalGrandTotal = Math.max(0, finalGrandTotal);

  const processedItems = purchaseInput.items.map(item => {
    const quantity = item.quantity || 0;
    const rate = item.rate || 0;
    const itemGstRate = item.gstRate || 0;
    const taxInclusive = item.taxInclusive || false;
    return { ...item, ...processedItems.find(pItem => pItem.id === item.id) };
  });

  return {
    processedItems,
    grossTotal: totalGrossAmount,
    totalItemDiscount: totalItemDiscountAmount,
    subtotal: roundToDecimal(totalGrossAmount - totalItemDiscountAmount),
    totalTaxableAmount: totalTaxableAmount,
    totalCGST: totalCGST,
    totalSGST: totalSGST,
    totalIGST: totalIGST,
    totalCess: totalCess,
    totalTax: totalTotalTax,
    invoiceDiscount: invoiceDiscount,
    invoiceDiscountType: invoiceDiscountType,
    freightCharges: freightCharges,
    otherCharges: otherCharges,
    roundOff: roundOff,
    grandTotal: finalGrandTotal,
    calculationVersion: CALCULATION_VERSION,
  };
};