import React, { useState, useEffect } from "react";
import { Plus, Edit, Trash2, Search, ChevronDown, Settings, Users, Shield, Globe, Database, Scale, MessageCircle } from "lucide-react";
import api from "../../services/api";
import { useNavigate } from "react-router-dom";
import ImportHistoryManager from "../../components/ImportHistoryManager";

export default function SettingsPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("parties");
  const [parties, setParties] = useState([]);
  const [units, setUnits] = useState([]);
  const [categories, setCategories] = useState([]);
  const [subCategories, setSubCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(false);

  // Form states
  const [showPartyForm, setShowPartyForm] = useState(false);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [showSubCategoryForm, setShowSubCategoryForm] = useState(false);
  const [showBrandForm, setShowBrandForm] = useState(false);

  const [editingPartyId, setEditingPartyId] = useState(null);
  const [editingCategoryId, setEditingCategoryId] = useState(null);
  const [editingSubCategoryId, setEditingSubCategoryId] = useState(null);
  const [editingBrandId, setEditingBrandId] = useState(null);

  const [partyForm, setPartyForm] = useState({
    name: "",
    partyType: "both",
    mobileNumber: "",
    address: "",
    gstNumber: "",
    contactPerson: "",
  });

  const [categoryForm, setCategoryForm] = useState({
    name: "",
    description: "",
  });

  const [subCategoryForm, setSubCategoryForm] = useState({
    name: "",
    description: "",
  });

  const [brandForm, setBrandForm] = useState({
    name: "",
    description: "",
  });

  useEffect(() => {
    if (activeTab === "parties") loadParties();
    if (activeTab === "categories") loadCategories();
    if (activeTab === "subCategories") loadSubCategories();
    if (activeTab === "brands") loadBrands();
  }, [activeTab]);

  const loadParties = async () => {
    try {
      setLoading(true);
      const response = await api.get("/api/party");
      const data = response?.data?.parties || response?.parties || response?.data;
      setParties(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Error loading parties:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadCategories = async () => {
    try {
      setLoading(true);
      const response = await api.get("/api/category");
      const data = response?.data?.categories || response?.categories || response?.data;
      setCategories(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Error loading categories:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadSubCategories = async () => {
    try {
      setLoading(true);
      const response = await api.get("/api/subcategory");
      const data = response?.data?.subCategories || response?.subCategories || response?.data;
      setSubCategories(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Error loading sub-categories:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadBrands = async () => {
    try {
      setLoading(true);
      const response = await api.get("/api/brand");
      const data = response?.data?.brands || response?.brands || response?.data;
      setBrands(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Error loading brands:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddParty = async (e) => {
    e.preventDefault();
    try {
      if (editingPartyId) {
        await api.put(`/api/party/${editingPartyId}`, partyForm);
        alert("Party updated successfully!");
      } else {
        await api.post("/api/party", partyForm);
        alert("Party added successfully!");
      }
      setPartyForm({
        name: "",
        partyType: "both",
        mobileNumber: "",
        address: "",
        gstNumber: "",
        contactPerson: "",
      });
      setEditingPartyId(null);
      setShowPartyForm(false);
      loadParties();
    } catch (err) {
      alert(err.error || err.response?.data?.message || "Error saving party");
    }
  };

  const handleEditParty = (party) => {
    setPartyForm({
      name: party.name || "",
      partyType: party.partyType || "both",
      mobileNumber: party.mobileNumber || "",
      address: party.address || "",
      gstNumber: party.gstNumber || "",
      contactPerson: party.contactPerson || "",
    });
    setEditingPartyId(party._id);
    setShowPartyForm(true);
  };

  const handleAddCategory = async (e) => {
    e.preventDefault();
    try {
      if (editingCategoryId) {
        await api.put(`/api/category/${editingCategoryId}`, categoryForm);
        alert("Category updated successfully!");
      } else {
        await api.post("/api/category", categoryForm);
        alert("Category added successfully!");
      }
      setCategoryForm({ name: "", description: "" });
      setEditingCategoryId(null);
      setShowCategoryForm(false);
      loadCategories();
    } catch (err) {
      alert(err.error || err.response?.data?.message || "Error saving category");
    }
  };

  const handleEditCategory = (cat) => {
    setCategoryForm({ name: cat.name || "", description: cat.description || "" });
    setEditingCategoryId(cat._id);
    setShowCategoryForm(true);
  };

  const handleAddSubCategory = async (e) => {
    e.preventDefault();
    try {
      if (editingSubCategoryId) {
        await api.put(`/api/subcategory/${editingSubCategoryId}`, subCategoryForm);
        alert("Sub-Category updated successfully!");
      } else {
        await api.post("/api/subcategory", subCategoryForm);
        alert("Sub-Category added successfully!");
      }
      setSubCategoryForm({ name: "", description: "" });
      setEditingSubCategoryId(null);
      setShowSubCategoryForm(false);
      loadSubCategories();
    } catch (err) {
      alert(err.error || err.response?.data?.message || "Error adding sub-category");
    }
  };

  const handleEditSubCategory = (sub) => {
    setSubCategoryForm({ name: sub.name || "", description: sub.description || "" });
    setEditingSubCategoryId(sub._id);
    setShowSubCategoryForm(true);
  };

  const handleAddBrand = async (e) => {
    e.preventDefault();
    try {
      if (editingBrandId) {
        await api.put(`/api/brand/${editingBrandId}`, brandForm);
        alert("Brand updated successfully!");
      } else {
        await api.post("/api/brand", brandForm);
        alert("Brand added successfully!");
      }
      setBrandForm({ name: "", description: "" });
      setEditingBrandId(null);
      setShowBrandForm(false);
      loadBrands();
    } catch (err) {
      alert(err.error || err.response?.data?.message || "Error adding brand");
    }
  };

  const handleEditBrand = (brand) => {
    setBrandForm({ name: brand.name || "", description: brand.description || "" });
    setEditingBrandId(brand._id);
    setShowBrandForm(true);
  };

  const handleDeleteParty = async (id) => {
    if (window.confirm("Delete this party?")) {
      try {
        await api.delete(`/api/party/${id}`);
        loadParties();
      } catch (err) {
        alert("Error deleting party");
      }
    }
  };

  const handleDeleteCategory = async (id) => {
    if (window.confirm("Delete this category?")) {
      try {
        await api.delete(`/api/category/${id}`);
        loadCategories();
      } catch (err) {
        alert("Error deleting category");
      }
    }
  };

  const handleDeleteSubCategory = async (id) => {
    if (window.confirm("Delete this sub-category?")) {
      try {
        await api.delete(`/api/subcategory/${id}`);
        loadSubCategories();
      } catch (err) {
        alert("Error deleting sub-category");
      }
    }
  };

  const handleDeleteBrand = async (id) => {
    if (window.confirm("Delete this brand?")) {
      try {
        await api.delete(`/api/brand/${id}`);
        loadBrands();
      } catch (err) {
        alert("Error deleting brand");
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-1">Manage application settings and master data</p>
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <button onClick={() => navigate("/settings/app")} className="p-4 bg-white border rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-2 text-center">
          <div className="p-2 bg-blue-50 rounded-full text-blue-600"><Settings size={24} /></div>
          <span className="font-medium text-gray-700">App Settings</span>
        </button>
        <button onClick={() => navigate("/settings/staff")} className="p-4 bg-white border rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-2 text-center">
          <div className="p-2 bg-green-50 rounded-full text-green-600"><Users size={24} /></div>
          <span className="font-medium text-gray-700">Staff Management</span>
        </button>
        <button onClick={() => navigate("/settings/web")} className="p-4 bg-white border rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-2 text-center">
          <div className="p-2 bg-purple-50 rounded-full text-purple-600"><Globe size={24} /></div>
          <span className="font-medium text-gray-700">Web Preferences</span>
        </button>
        <button onClick={() => navigate("/settings/backup")} className="p-4 bg-white border rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-2 text-center">
          <div className="p-2 bg-orange-50 rounded-full text-orange-600"><Database size={24} /></div>
          <span className="font-medium text-gray-700">Backup & Restore</span>
        </button>
        <button onClick={() => navigate("/inventory/masters")} className="p-4 bg-white border rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-2 text-center">
          <div className="p-2 bg-indigo-50 rounded-full text-indigo-600"><Scale size={24} /></div>
          <span className="font-medium text-gray-700">Unit Settings</span>
        </button>
        <button onClick={() => navigate("/settings/whatsapp")} className="p-4 bg-white border rounded-xl shadow-sm hover:shadow-md transition flex flex-col items-center gap-2 text-center">
          <div className="p-2 bg-green-50 rounded-full text-green-600"><MessageCircle size={24} /></div>
          <span className="font-medium text-gray-700">WhatsApp API</span>
        </button>
      </div>

      <div className="border-t pt-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Master Data</h2>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-gray-200 overflow-x-auto">
        {[
          { id: "parties", label: "Parties" },
          { id: "categories", label: "Categories" },
          { id: "subCategories", label: "Sub-Categories" },
        { id: "brands", label: "Brands / Companies" },
        { id: "imports", label: "Import History" }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 font-medium border-b-2 transition whitespace-nowrap ${
              activeTab === tab.id
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* PARTIES TAB */}
      {activeTab === "parties" && (
        <div className="space-y-4">
          <button
            onClick={() => {
              setPartyForm({ name: "", partyType: "both", mobileNumber: "", address: "", gstNumber: "", contactPerson: "" });
              setEditingPartyId(null);
              setShowPartyForm(!showPartyForm);
            }}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            <Plus size={20} />
            Add Party
          </button>

          {showPartyForm && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-bold mb-4">{editingPartyId ? "Edit Party" : "Add New Party"}</h2>
              <form onSubmit={handleAddParty} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Party Name *"
                    value={partyForm.name}
                    onChange={(e) => setPartyForm({ ...partyForm, name: e.target.value })}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                  <select
                    value={partyForm.partyType}
                    onChange={(e) => setPartyForm({ ...partyForm, partyType: e.target.value })}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="both">Both (Supplier & Customer)</option>
                    <option value="supplier">Supplier</option>
                    <option value="customer">Customer</option>
                  </select>
                  <input
                    type="text"
                    placeholder="Mobile Number *"
                    value={partyForm.mobileNumber}
                    onChange={(e) => setPartyForm({ ...partyForm, mobileNumber: e.target.value })}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                  <input
                    type="text"
                    placeholder="GST Number"
                    value={partyForm.gstNumber}
                    onChange={(e) => setPartyForm({ ...partyForm, gstNumber: e.target.value })}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <input
                    type="text"
                    placeholder="Contact Person"
                    value={partyForm.contactPerson}
                    onChange={(e) => setPartyForm({ ...partyForm, contactPerson: e.target.value })}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <textarea
                  placeholder="Address *"
                  value={partyForm.address}
                  onChange={(e) => setPartyForm({ ...partyForm, address: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows="2"
                  required
                />
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    {editingPartyId ? "Update Party" : "Add Party"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowPartyForm(false);
                      setEditingPartyId(null);
                    }}
                    className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Mobile</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">GST</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
                  <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {parties.length > 0 ? (
                  parties.map((party) => (
                    <tr key={party._id} className="border-b hover:bg-gray-50">
                      <td className="px-6 py-3 font-medium">{party.name}</td>
                      <td className="px-6 py-3">{party.mobileNumber}</td>
                      <td className="px-6 py-3">{party.gstNumber || "-"}</td>
                      <td className="px-6 py-3 text-sm">
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          {party.partyType}
                        </span>
                      </td>
                      <td className="px-6 py-3 text-center flex justify-center gap-2">
                        <button onClick={() => handleEditParty(party)} className="p-2 text-blue-600 hover:bg-blue-50 rounded">
                          <Edit size={18} />
                        </button>
                        <button
                          onClick={() => handleDeleteParty(party._id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded"
                        >
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" className="px-6 py-8 text-center text-gray-500">
                      No parties added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CATEGORIES TAB */}
      {activeTab === "categories" && (
        <div className="space-y-4">
          <button
            onClick={() => {
              setCategoryForm({ name: "", description: "" });
              setEditingCategoryId(null);
              setShowCategoryForm(!showCategoryForm);
            }}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            <Plus size={20} />
            Add Category
          </button>

          {showCategoryForm && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-bold mb-4">{editingCategoryId ? "Edit Category" : "Add New Category"}</h2>
              <form onSubmit={handleAddCategory} className="space-y-4">
                <input
                  type="text"
                  placeholder="Category Name *"
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
                <textarea
                  placeholder="Description"
                  value={categoryForm.description}
                  onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows="2"
                />
                <div className="flex gap-2">
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    {editingCategoryId ? "Update Category" : "Add Category"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowCategoryForm(false);
                      setEditingCategoryId(null);
                    }}
                    className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Category Name</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Description</th>
                  <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {categories.length > 0 ? (
                  categories.map((category) => (
                    <tr key={category._id} className="border-b hover:bg-gray-50">
                      <td className="px-6 py-3 font-medium">{category.name}</td>
                      <td className="px-6 py-3 text-sm text-gray-600">{category.description || "-"}</td>
                      <td className="px-6 py-3 text-center flex justify-center gap-2">
                        <button onClick={() => handleEditCategory(category)} className="p-2 text-blue-600 hover:bg-blue-50 rounded">
                          <Edit size={18} />
                        </button>
                        <button
                          onClick={() => handleDeleteCategory(category._id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded"
                        >
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="3" className="px-6 py-8 text-center text-gray-500">
                      No categories added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-CATEGORIES TAB */}
      {activeTab === "subCategories" && (
        <div className="space-y-4">
          <button
            onClick={() => {
              setSubCategoryForm({ name: "", description: "" });
              setEditingSubCategoryId(null);
              setShowSubCategoryForm(!showSubCategoryForm);
            }}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            <Plus size={20} /> Add Sub-Category
          </button>

          {showSubCategoryForm && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-bold mb-4">{editingSubCategoryId ? "Edit Sub-Category" : "Add New Sub-Category"}</h2>
              <form onSubmit={handleAddSubCategory} className="space-y-4">
                <input
                  type="text"
                  placeholder="Sub-Category Name *"
                  value={subCategoryForm.name}
                  onChange={(e) => setSubCategoryForm({ ...subCategoryForm, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
                <textarea
                  placeholder="Description"
                  value={subCategoryForm.description}
                  onChange={(e) => setSubCategoryForm({ ...subCategoryForm, description: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows="2"
                />
                <div className="flex gap-2">
                  <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">{editingSubCategoryId ? "Update Sub-Category" : "Add Sub-Category"}</button>
                  <button type="button" onClick={() => {
                    setShowSubCategoryForm(false);
                    setEditingSubCategoryId(null);
                  }} className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">Cancel</button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Sub-Category Name</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Description</th>
                  <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {subCategories.length > 0 ? (
                  subCategories.map((sub) => (
                    <tr key={sub._id} className="border-b hover:bg-gray-50">
                      <td className="px-6 py-3 font-medium">{sub.name}</td>
                      <td className="px-6 py-3 text-sm text-gray-600">{sub.description || "-"}</td>
                      <td className="px-6 py-3 text-center flex justify-center gap-2">
                        <button onClick={() => handleEditSubCategory(sub)} className="p-2 text-blue-600 hover:bg-blue-50 rounded">
                          <Edit size={18} />
                        </button>
                        <button onClick={() => handleDeleteSubCategory(sub._id)} className="p-2 text-red-600 hover:bg-red-50 rounded">
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan="3" className="px-6 py-8 text-center text-gray-500">No sub-categories added yet</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* BRANDS TAB */}
      {activeTab === "brands" && (
        <div className="space-y-4">
          <button
            onClick={() => {
              setBrandForm({ name: "", description: "" });
              setEditingBrandId(null);
              setShowBrandForm(!showBrandForm);
            }}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            <Plus size={20} /> Add Brand
          </button>

          {showBrandForm && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-bold mb-4">{editingBrandId ? "Edit Brand" : "Add New Brand / Company"}</h2>
              <form onSubmit={handleAddBrand} className="space-y-4">
                <input
                  type="text"
                  placeholder="Brand Name (e.g., Samsung) *"
                  value={brandForm.name}
                  onChange={(e) => setBrandForm({ ...brandForm, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
                <textarea
                  placeholder="Description"
                  value={brandForm.description}
                  onChange={(e) => setBrandForm({ ...brandForm, description: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows="2"
                />
                <div className="flex gap-2">
                  <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">{editingBrandId ? "Update Brand" : "Add Brand"}</button>
                  <button type="button" onClick={() => {
                    setShowBrandForm(false);
                    setEditingBrandId(null);
                  }} className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">Cancel</button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Brand Name</th>
                  <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Description</th>
                  <th className="px-6 py-3 text-center text-xs font-semibold text-gray-600 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody>
                {brands.length > 0 ? (
                  brands.map((brand) => (
                    <tr key={brand._id} className="border-b hover:bg-gray-50">
                      <td className="px-6 py-3 font-medium">{brand.name}</td>
                      <td className="px-6 py-3 text-sm text-gray-600">{brand.description || "-"}</td>
                      <td className="px-6 py-3 text-center flex justify-center gap-2">
                        <button onClick={() => handleEditBrand(brand)} className="p-2 text-blue-600 hover:bg-blue-50 rounded">
                          <Edit size={18} />
                        </button>
                        <button onClick={() => handleDeleteBrand(brand._id)} className="p-2 text-red-600 hover:bg-red-50 rounded">
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan="3" className="px-6 py-8 text-center text-gray-500">No brands added yet</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* IMPORTS TAB */}
      {activeTab === "imports" && (
        <div className="space-y-4">
          <ImportHistoryManager />
        </div>
      )}

    </div>
  );
}
