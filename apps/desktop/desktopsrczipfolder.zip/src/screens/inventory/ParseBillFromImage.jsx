import React, { useState, useEffect, useRef } from "react";
import { Upload, FileText, Check, Loader2, ArrowRight, AlertTriangle, CheckCircle, Plus, Camera as CameraIcon, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import api from "../../services/api";
import Button from "../../components/Button";
import { dbService } from "../../services/dbService";
import { auditService } from "../../services/auditService";
import { syncQueue } from "@repo/shared";

const ParseBillFromImage = () => {
  const navigate = useNavigate();
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [parsedData, setParsedData] = useState(null);
  const [localProducts, setLocalProducts] = useState([]);
  
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  useEffect(() => {
    const loadProducts = async () => {
      const products = await dbService.getInventory?.() || [];
      setLocalProducts(products);
    };
    loadProducts();
  }, []);

  // Smart Word Matching Algorithm (Fuzzy Logic)
  const calculateSimilarity = (str1, str2) => {
    const s1 = str1.toLowerCase().replace(/[^a-z0-9]/g, ' ').split(/\s+/).filter(Boolean);
    const s2 = str2.toLowerCase().replace(/[^a-z0-9]/g, ' ').split(/\s+/).filter(Boolean);
    if (s1.length === 0 || s2.length === 0) return 0;
    const set1 = new Set(s1);
    const set2 = new Set(s2);
    const intersection = new Set([...set1].filter(x => set2.has(x)));
    const union = new Set([...set1, ...set2]);
    return intersection.size / union.size; // Returns 0 to 1
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      setPreview(URL.createObjectURL(file));
      setParsedData(null);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, facingMode: 'environment' });
      if (videoRef.current) videoRef.current.srcObject = stream;
      setIsCameraOpen(true);
    } catch (err) {
      alert("Camera access denied or no camera found on this device.");
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      videoRef.current.srcObject.getTracks().forEach(track => track.stop());
    }
    setIsCameraOpen(false);
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext("2d");
      canvasRef.current.width = videoRef.current.videoWidth;
      canvasRef.current.height = videoRef.current.videoHeight;
      context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
      
      const dataUrl = canvasRef.current.toDataURL("image/jpeg", 0.7); // 0.7 for compression
      setPreview(dataUrl);
      setImage(dataUrl); // Use Data URL
      setParsedData(null);
      stopCamera();
    }
  };

  useEffect(() => {
    return () => { if (isCameraOpen) stopCamera(); };
  }, [isCameraOpen]);

  const handleScan = () => {
    if (!image) return;
    setScanning(true);

    // Simulate OCR Scanning Process
    setTimeout(() => {
      setScanning(false);
      // Mock Data - In real app, this comes from backend OCR
      setParsedData({
        supplierName: "Demo Supplier Enterprises",
        invoiceNumber: "INV-" + Math.floor(Math.random() * 10000),
        date: new Date().toISOString().split("T")[0],
        totalAmount: 15000,
        items: [
          { name: "Detected Item A", quantity: 10, price: 500 },
          { name: "Detected Item B", quantity: 5, price: 2000 },
        ],
      });
    }, 2000);
  };

  const handleConfirm = async () => {
    if (!parsedData) return;
    try {
      const newId = crypto.randomUUID ? crypto.randomUUID() : `PUR-OCR-${Date.now()}`;
      const payload = { ...parsedData, _id: newId, uuid: newId, paymentMethod: 'credit' };

      // 1. Save Locally
      if (dbService.savePurchase) await dbService.savePurchase(payload);

      // 2. Try to update stock locally if products match by name
      const localProducts = await dbService.getInventory?.() || [];
      for (const item of payload.items) {
        const matchedProduct = localProducts.find(p => p.name.toLowerCase() === item.name.toLowerCase());
        if (matchedProduct) {
          const updatedProduct = { ...matchedProduct, currentStock: (parseFloat(matchedProduct.currentStock) || 0) + item.quantity };
          await dbService.updateProduct(matchedProduct._id, updatedProduct);
        }
      }

      await auditService.logAction('CREATE', 'purchase', null, payload);

      // 3. Queue for Cloud Sync
      await syncQueue.enqueue({ entityId: newId, entity: 'purchase', method: "POST", url: "/api/purchase", data: payload });

      alert("Purchase Entry Scanned & Saved Offline Successfully!");
      navigate("/inventory");
    } catch (error) {
      console.error("Failed to save:", error);
      alert("Failed to save purchase entry: " + error.message);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <FileText className="text-blue-600" /> Scan Purchase Bill
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left: Image Upload */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center bg-gray-50 flex flex-col items-center justify-center min-h-[300px]">
            {isCameraOpen ? (
              <div className="relative w-full bg-black rounded-lg overflow-hidden flex flex-col items-center">
                <video ref={videoRef} autoPlay playsInline className="max-h-64 w-full object-contain" />
                <canvas ref={canvasRef} className="hidden" />
                <div className="absolute bottom-4 flex gap-4">
                  <button onClick={captureImage} className="bg-blue-600 text-white px-4 py-2 rounded-full font-bold shadow-lg hover:bg-blue-700">Capture Bill</button>
                  <button onClick={stopCamera} className="bg-red-600 text-white p-2 rounded-full shadow-lg hover:bg-red-700"><X size={20} /></button>
                </div>
              </div>
            ) : preview ? (
              <div className="w-full">
                <img src={preview} alt="Bill Preview" className="max-h-64 mx-auto rounded shadow-sm mb-4" />
                <div className="flex justify-center gap-2">
                  <label htmlFor="bill-upload" className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg cursor-pointer hover:bg-gray-50 font-medium text-sm shadow-sm">
                    Change File
                  </label>
                  <button onClick={startCamera} className="px-4 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 flex items-center gap-2 font-medium text-sm shadow-sm">
                    <CameraIcon size={16} /> Retake
                  </button>
                </div>
              </div>
            ) : (
              <div className="py-4 text-gray-500 flex flex-col items-center">
                <Upload size={48} className="mx-auto mb-4 text-gray-400" />
                <p className="mb-4 font-medium">Upload or Capture Bill Image</p>
                <div className="flex flex-wrap justify-center gap-3">
                  <label htmlFor="bill-upload" className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg cursor-pointer hover:bg-gray-50 flex items-center gap-2 font-medium text-sm shadow-sm">
                    <Upload size={16} /> Browse File
                  </label>
                  <button onClick={startCamera} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 font-medium text-sm shadow-sm">
                    <CameraIcon size={16} /> Open Camera
                  </button>
                </div>
              </div>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
              id="bill-upload"
            />
          </div>

          <Button
            onClick={handleScan}
            disabled={!image || scanning}
            className="w-full mt-4"
          >
            {scanning ? (
              <><Loader2 className="animate-spin" size={20} /> Scanning...</>
            ) : (
              "Extract Data"
            )}
          </Button>
        </div>

        {/* Right: Parsed Data Preview */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="font-semibold text-lg mb-4 border-b pb-2">Extracted Details</h3>
          
          {parsedData ? (
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-500">Supplier</label>
                <p className="font-medium">{parsedData.supplierName}</p>
              </div>
              <div className="flex justify-between">
                <div>
                  <label className="text-xs text-gray-500">Invoice No</label>
                  <p className="font-medium">{parsedData.invoiceNumber}</p>
                </div>
                <div>
                  <label className="text-xs text-gray-500">Date</label>
                  <p className="font-medium">{parsedData.date}</p>
                </div>
              </div>
              <div className="bg-green-50 p-3 rounded border border-green-100">
                <p className="text-sm text-green-800">Total Amount</p>
                <p className="text-xl font-bold text-green-700">₹{parsedData.totalAmount}</p>
              </div>
              
              {/* Smart Items List UI */}
              <div className="mt-4">
                <h4 className="font-semibold text-sm mb-2 text-gray-700">Items Scanned ({parsedData.items.length})</h4>
                <div className="space-y-3">
                  {parsedData.items.map((item, idx) => (
                    <div key={idx} className={`p-3 rounded border text-sm ${item.matchStatus === 'exact' ? 'bg-green-50 border-green-200' : item.matchStatus === 'partial' ? 'bg-yellow-50 border-yellow-300' : 'bg-blue-50 border-blue-200'}`}>
                      
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium text-gray-800">{item.name}</span>
                        <span className="font-bold text-gray-700">x{item.quantity}</span>
                      </div>
                      
                      {item.matchStatus === 'exact' && (
                        <p className="text-xs text-green-600 flex items-center gap-1 mt-1"><CheckCircle size={14}/> Matched perfectly with inventory</p>
                      )}
                      
                      {item.matchStatus === 'new' && (
                        <p className="text-xs text-blue-600 flex items-center gap-1 mt-1"><Plus size={14}/> Will be added as a NEW product</p>
                      )}

                      {item.matchStatus === 'partial' && (
                        <div className="mt-2 pt-2 border-t border-yellow-200">
                          <p className="text-xs text-yellow-800 flex items-center gap-1 mb-2">
                            <AlertTriangle size={14}/> {item.similarity}% Match Found: <strong>{item.suggestedProduct.name}</strong>
                          </p>
                          <div className="flex gap-2">
                            <button onClick={() => resolveItemConflict(idx, 'merge')} className="px-3 py-1 bg-yellow-600 text-white rounded text-xs hover:bg-yellow-700 font-medium">Merge to this</button>
                            <button onClick={() => resolveItemConflict(idx, 'keep_new')} className="px-3 py-1 bg-white border border-yellow-600 text-yellow-700 rounded text-xs hover:bg-yellow-50 font-medium">Add as New Instead</button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <Button onClick={handleConfirm} type="success" className="w-full mt-4">
                <Check size={20} /> Confirm & Save
              </Button>
            </div>
          ) : (
            <div className="text-center py-20 text-gray-400">
              <ArrowRight size={32} className="mx-auto mb-2 opacity-50" />
              <p>Scan an image to see details here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ParseBillFromImage;